list = []
print len(list)
if not len(list):
    print "the list is empty!"
else:
    print "not empty!"

list = [1, 2, 3]
print len(list)
print range(len(list))
list.pop()
print list

iter = 3
for iter in range(10):
    print iter