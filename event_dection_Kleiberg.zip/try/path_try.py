import codecs

month = 2
path = r'../data_source/data_time_' + str(month) + '.txt'
#path = r'../data_source/data_time_2.txt'
print path

file_read = codecs.open(path, mode='r', encoding="utf-8")
file_read.close()