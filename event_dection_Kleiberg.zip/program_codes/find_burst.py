# -*- coding:utf-8 -*-


from __future__ import division
import numpy as np
import math
import codecs
import datetime
import time_transform

def kleinberg(offsets, s=2, gamma=1):
    if s <= 1:
        raise ValueError("s must be greater than 1!")
    if gamma <= 0:
        raise ValueError("gamma must be positive!")
    if len(offsets) < 1:
        raise ValueError("offsets must be non-empty!")

    offsets = np.array(offsets, dtype=object)

    if offsets.size == 1:
        bursts = np.array([0, offsets[0], offsets[0]], ndmin=2, dtype=object)
        return bursts

    offsets = np.sort(offsets)
    gaps = np.diff(offsets)

    """
    去掉其中的负数与零值
    """
    """
    new_gap = []
    for gap in gaps:
        if gap > 0:
            new_gap.append(gap)
    gaps = new_gap
    """


    if not np.all(gaps):
        raise ValueError("Input cannot contain events with zero time between!")

    T = np.sum(gaps)
    n = np.size(gaps)
    g_hat = T / n

    k = int(math.ceil(float(1 + math.log(T, s) + math.log(1 / np.amin(gaps), s))))

    gamma_log_n = gamma * math.log(n)

    def tau(i, j):
        if i >= j:
            return 0
        else:
            return (j - i) * gamma_log_n

    alpha_function = np.vectorize(lambda x: s ** x / g_hat)
    alpha = alpha_function(np.arange(k))

    def f(j, x):
        return alpha[j] * math.exp(-alpha[j] * x)

    C = np.repeat(float("inf"), k)
    C[0] = 0

    q = np.empty((k, 0))
    for t in range(n):
        C_prime = np.repeat(float("inf"), k)
        q_prime = np.empty((k, t + 1))
        q_prime.fill(np.nan)

        for j in range(k):
            cost_function = np.vectorize(lambda x: C[x] + tau(x, j))
            cost = cost_function(np.arange(0, k))

            el = np.argmin(cost)

            if f(j, gaps[t]) > 0:
                C_prime[j] = cost[el] - math.log(f(j, gaps[t]))

            if t > 0:
                q_prime[j, :t] = q[el, :]

            q_prime[j, t] = j + 1

        C = C_prime
        q = q_prime

    j = np.argmin(C)
    q = q[j, :]

    prev_q = 0

    N = 0
    for t in range(n):
        if q[t] > prev_q:
            N = N + q[t] - prev_q
        prev_q = q[t]

    bursts = np.array([np.repeat(np.nan, N), np.repeat(offsets[0], N), np.repeat(offsets[0], N)], ndmin=2,
                      dtype=object).transpose()

    burst_counter = -1
    prev_q = 0
    stack = np.repeat(np.nan, N)
    stack_counter = -1
    for t in range(n):
        if q[t] > prev_q:
            num_levels_opened = q[t] - prev_q
            for i in range(int(num_levels_opened)):
                burst_counter += 1
                bursts[burst_counter, 0] = prev_q + i
                bursts[burst_counter, 1] = offsets[t]
                stack_counter += 1
                stack[stack_counter] = burst_counter
        elif q[t] < prev_q:
            num_levels_closed = prev_q - q[t]
            for i in range(int(num_levels_closed)):
                bursts[int(stack[stack_counter]), 2] = offsets[t]
                stack_counter -= 1
        prev_q = q[t]

    while stack_counter >= 0:
        bursts[int(stack[int(stack_counter)]), 2] = offsets[n]
        stack_counter -= 1
    return bursts

def arrayprocess(offsets):
    newoffsets = []
    for num in offsets:
        numNum = num * 100
        newoffsets.append(numNum)
    #print newoffsets
    return newoffsets

"""
从状态列表中找到各个事件所对应的第一个1状态
方法：若出现2及以上状态，认为该天出现了事件,再从其中找到所属的1状态
"""
def find_first_2state(path_read = r'../data_created/state_list.txt'):
    file_state = codecs.open(path_read, mode='r', encoding="utf-8")

    start_time_list = []
    end_time_list = []
    event_time_list = []
    data_list = []


    for line in file_state:
        text = line.strip()
        text = text.split(' ', 3)
        list_temp = []
        state = int(float(text[0]))
        start_time = long(long(text[1]) / 1000)
        end_time = long(long(text[2]) / 1000)
        start_time_list.append(start_time)
        end_time_list.append(end_time)
        temp_list = [state, start_time, end_time]
        data_list.append(temp_list)

    start_time_all = min(start_time_list)
    end_time_all = min(end_time_list)
    #event_time.append([start_time_all,end_time_all])

    #先找到一个2状态，认为其前后一天从属于该2状态所属的时间
    for data in data_list:
        state = data[0]
        start_time = data[1]
        end_time = data[2]
        if state >= 2:
            #假设改状态前后一天为事件持续时间
            start_time_event = start_time - 3600*6
            end_time_event = end_time + 3600*6


            #print "\t开始时间：\t" + time_transform.timestamp_datetime_GMT(start_time_event)
            #print "\t结束时间：\t" + time_transform.timestamp_datetime_GMT(end_time_event)
            #print event_time_list

            if not len(event_time_list):
                # 列表仍为空，需要加入
                event_time_list.append([start_time_event, end_time_event])
            else:
                for event_time in event_time_list:
                    if start_time_event < event_time[0]:
                        if end_time_event >= event_time[0]:
                            #认为其为同一事件，并将开始时间向前推
                            event_time[0] = start_time_event
                        else:
                            #认为其是不同事件
                            event_time_list.append([start_time_event, end_time_event])
                    elif end_time_event >= event_time[1]:
                        if start_time_event <= event_time[1]:
                            event_time[1] = end_time_event
                        else:
                            event_time_list.append([start_time_event, end_time_event])
            #print "\t开始时间：\t" + time_transform.timestamp_datetime_GMT(event_time_list[0][0])
            #print "\t结束时间：\t" + time_transform.timestamp_datetime_GMT(event_time_list[0][1]) + "\n"



    #按开始时间将事件的时间段进行排序
    #排序方式：冒泡排序
    length = len(event_time_list)
    n = length
    for iter in range(length):
        i = 0
        while i < (iter-1):
            i += 1
            if event_time_list[i][0] > event_time_list[i+1][0]:
                temp_time = event_time_list[i]
                event_time_list[i] = event_time_list[i+1]
                event_time_list[i+1] = temp_time

    #将有重合时间的事件进行合并
    flag_has_overlap = True
    count = 0

    while flag_has_overlap:
        flag_has_overlap = False
        #print "has overlap"
        last_time = 0
        for count in range(len(event_time_list)):
            if count != 0:
                if event_time_list[count][0] < event_time_list[count-1][1]:
                    flag_has_overlap = True
                    break
        if flag_has_overlap:
            for iter in range(len(event_time_list)):
                if iter == (count-1):
                    event_time_list[iter][1] = event_time_list[iter+1][1]
                if iter > count:
                    event_time_list[iter-1] = event_time_list[iter]
            event_time_list.pop()

    print "共有%d个事件" % len(event_time_list)
    count = 0

    #找每个事件的时间期间其中的1状态
    for event_time in event_time_list:
        #将开始值设为最大值，将终止值设为最小值
        start_time_event = event_time[1]
        end_time_event = event_time[0]


        for data in data_list:
            state = data[0]
            start_time = data[1]
            end_time = data[2]
            if state == 1:
                if (start_time > event_time[0]) and (end_time < event_time[1]):
                    if start_time < start_time_event:
                        start_time_event = start_time
                    elif end_time > end_time_event:
                        end_time_event = end_time

        #event_time[0] = start_time_event
        #event_time[1] = end_time_event

        start_time = time_transform.timestamp_datetime_GMT(event_time_list[count][0])
        end_time = time_transform.timestamp_datetime_GMT(event_time_list[count][1])
        print "第%d个事件："%(count+1)
        print "\t由2状态找到的事件的大致时间："
        print "\t开始时间：\t" + start_time
        print "\t结束时间：\t" + end_time

        event_time[0] = start_time_event
        event_time[1] = end_time_event

        start_time = time_transform.timestamp_datetime_GMT(event_time_list[count][0])
        end_time = time_transform.timestamp_datetime_GMT(event_time_list[count][1])
        print "\t由1状态找到的事件的准确时间："
        print "\t开始时间：\t" + start_time
        #print "\t结束时间：\t" + end_time
        count += 1


    file_state.close()


if __name__ == '__main__':
    #print "OK"
    offsets = [4, 17, 23, 27, 33, 35, 37, 76, 77, 82, 84, 88, 90, 92]
    #offsets = arrayprocess(offsets)
    #print offsets
    #offsets.append(9201)
    #offsets.append(9202)
    #print offsets
    #print kleinberg(offsets, s=2, gamma=0.1)
    find_first_2state()
