# -*- coding:utf-8 -*-

import codecs
import pymongo
from pymongo.errors import *
import time
import time_transform

# 连接数据库
client = pymongo.MongoClient("mongodb://kb314:fzdwxxcl.314@121.49.99.14:30011")
colle = client.get_database('KeywordsTweets').get_collection('Terrorism4')
index_foramtion = colle.index_information()
print colle.count()

# 数据库中第一条推文id
first_text = colle.find().sort([("_id", 1)]).limit(1)
tweet = first_text[0]
print "数据库的开始时间："
timestamp = tweet.get("created_at_bj")
print time_transform.timestamp_datetime(timestamp)
#print timestamp

last_text = colle.find().sort([("_id", -1)]).limit(1)
tweet = last_text[0]
print "数据库的结束时间："
timestamp = tweet.get("created_at_bj")
print time_transform.timestamp_datetime(timestamp)
#print timestamp
#print long(first_text[0].get("_id"))-long(last_text[0].get("_id"))

#起始时间
threshold = 1521043200

collection_count = colle.count()
start_id = tweet.get("_id")
print type(start_id)
#end_id = start_id + ObjectId(collection_count)


