# -*- coding:utf-8 -*-
# <span style="font-size:12px;">
import time
import matplotlib.pyplot as plt
#from pymongo import MongoClient
import pymongo
import numpy as np
import codecs
from find_burst import kleinberg
from time_transform import timestamp_datetime
from time_transform import datetime_timestamp
from matplotlib.ticker import MultipleLocator, FuncFormatter
import matplotlib.dates as md
import datetime
import time_transform

class Dataprocess(object):
    def __init__(self, sample_rate=10, month=2, start_time='2018-3-20 00:00:00', end_time='2018-3-24 0:00:00'):
        self.time = []
        path_time_file = r'../data_source/data_time_' + str(month) + '.txt'
        #选择时间段
        flag_selec = True
        if flag_selec:
            self.select_file(start_time, end_time, path_time_file)

        # 对数据进行抽样
        self.sample_file(sample_rate)
        #读取数据
        self.file_time = self.read_data(r'../data_created/data_time_sampled.txt')

        #进行数据的处理
        self.check_sort(self.time)
        self.time.sort()
        self.max_repeat_num = self.find_repeat(self.time)
        self.time_processed = self.repeat_process(self.time, self.max_repeat_num)
        print "maxrepeatnum = :\t" + str(self.max_repeat_num)
        print "the number of timestamps:\t" + str(len(self.time_processed))
        #print "maxrepeatnum = :\t" + str(self.find_repeat(self.time_processed))

        self.state_list = []     #用以储存状态序列

    """
    从问问文档中读取初始的时间序列数据
    """
    def read_data(self, path_time = r'../data_source/data_time_2.txt'):
        file_time = codecs.open(path_time, mode='r', encoding="utf-8")
        for time in file_time:
            self.time.append(long(time))
        return file_time

    """
    对读取的时间序列进行采样
    """
    def sample_file(self, sample_rate=10, path_read = r'../data_created/data_time_selected.txt', path_write=r'../data_created/data_time_sampled.txt'):
        file_read = codecs.open(path_read, mode='r', encoding="utf-8")
        file_write = codecs.open(path_write, mode='w', encoding="utf-8")

        count = 0
        sample_count = 0
        for item in file_read:
            if count%sample_rate == 0:
                file_write.write(item)
                sample_count += 1
            count += 1

        file_read.close()
        file_write.close()

    """
    在时间序列中寻找是否有重复的时间，返回其重复次数的最大值
    """
    def find_repeat(self, time_list):
        last_time = 0
        count = 1
        total_num = 0
        maxcount = 1
        for time in time_list:
            if time == last_time:
                count += 1
                total_num += 1
                #print count
                if count > maxcount:
                    maxcount = count
            else:
                count = 1

            last_time = time
        print "the number of timestamps that repeat:\t\t" + str(total_num)
        return maxcount

    """
    对于重复的时间进行处理
    处理方法为：将所有时间序列按照最大重复次数等比扩大，将重复的时间均匀地插入
    """
    def repeat_process(self, time_list, max_repeat_num):
        last_time = 0
        repeat_count = 0
        time_processed = []
        for time in time_list:
            if time == last_time:
                repeat_count += 1
                time_processed.append(long(time)*(max_repeat_num)+repeat_count)
            else:
                time_processed.append(long(time)*(max_repeat_num))
                repeat_count = 0

            last_time = time
        return time_processed

    """
    查找是否还有不按照顺序排列的数据，若有，则进行修改
    """
    def check_sort(self, time_list):
        last_time = 0
        count = 0
        """
        for time in time_list:
            if time < last_time:
                #time = time/1000
                #print timestamp_datetime(time)
                count += 1
            else:
                new_list.append(time)
                last_time = time
        """
        for time in time_list:
            if time < last_time:
                count += 1
            else:
                last_time = time
        print "the number of the timestamp not in order:\t" + str(count)

    def paint_graph(self, time_list, groups_num = 100):
        start_time = time_list[0]
        end_time = time_list[-1]
        total_num = len(time_list)
        count_list = np.zeros(groups_num, dtype=np.int)
        gap = (float(end_time - start_time)) / float(groups_num)
        for time in time_list:
            index = int (float(time-start_time) / gap)
            if index == groups_num:
                index -= 1
            count_list[index] += 1
        print count_list

        x = np.array(range(groups_num))
        x_coordinate = []
        for iter in range(groups_num):
            x_coordinate.append(timestamp_datetime(1521388800 + iter*3600*(192 / groups_num)))
        #print x_coordinate

        #x = x % 24
        #plt.figure(figsize=(60, 30))
        #plt.xminorLocator = plt.MultipleLocator(24)
        #plt.ax = plt.subplot(111)
        #plt.ax.xaxis.set_minor_locator(plt.xminorLocator)
        plt.plot(x_coordinate, count_list, linestyle='-', color='green', marker='H')
        #plt.ax.xaxis.grid(True, which='major')  # x坐标轴的网格使用主刻度

        plt.rc('xtick', labelsize=50)

        plt.savefig("../figure/line.jpg")
        plt.show()

    def myplot(self, time_list):
        ax = plt.gca()
        ax = plt.axes()
        plt.xlabel("years(+2000)")  # 设置X轴的文字
        plt.ylabel("housing average price(*2000 yuan)")
        plt.ylim(0, 15)  # 设置Y轴的范围
        plt.title('line_regression & gradient decrease')  # 设置图表的标题
        plt.rc('xtick', labelsize=50)
        plt.rc('ytick', labelsize=18)
        plt.show()  # 显示图示

    """
    将所用的所有数据用折线图的形式展示出来
    """
    def plt_line_graph(self, time_list, groups_num = 100):
        plt.figure(figsize=(15, 12))
        plt.rcParams['font.sans-serif']=['SimHei']
        plt.rcParams['axes.unicode_minus']=False
        start_time = time_list[0]
        end_time = time_list[-1]
        total_num = len(time_list)
        count_list = np.zeros(groups_num, dtype=np.int)
        gap = (float(end_time - start_time)) / float(groups_num)
        for time in time_list:
            index = int(float(time - start_time) / gap)
            if index == groups_num:
                index -= 1
            count_list[index] += 1
        #print count_list

        x = np.array(range(groups_num))
        x_coordinate = []
        gap_x = int((end_time - start_time)/groups_num)/1000
        for iter in range(groups_num):
            #x_coordinate.append(start_time + iter * 3600 * (192 / groups_num))
            x_coordinate.append(start_time/1000 + iter * gap_x)
        #print x_coordinate

        show_flag = True

        if show_flag == True:
            xtime = [datetime.datetime.fromtimestamp(float(timestamp)) for timestamp in x_coordinate]
            #print "xtime_1:"
            #print xtime
            xtime = md.date2num(xtime)
            #print "xtime_2:"
            #print xtime
            plt.xticks(rotation=25)
            ax = plt.gca()
            xfmt = md.DateFormatter('%Y.%m.%d %H:%M:%S')
            ax.xaxis.set_major_formatter(xfmt)

            plt.plot(xtime, count_list, 'or')
            plt.plot(xtime, count_list, 'r')
            plt.xlabel(u"时间")
            plt.ylabel(u"推文数量")
            # plt.title("distribution of pgh")
            plt.grid(True)
            #plt.show()

        else:
            x_coordinate = [float(item) for item in x_coordinate]
            plt.plot(x_coordinate, count_list, 'or')
            plt.plot(x_coordinate, count_list)
            num = 20
            if len(x_coordinate) < num:
                x_abstract = x_coordinate
            else:
                x_step = (len(x_coordinate) + num / 2) / num
                #print "x_step:\t" + str(x_step)
                x_abstract = x_coordinate[::x_step]
            #print "len:\t" + str(len(x_abstract))
            xtime = [datetime.datetime.fromtimestamp(float(timestamp)) for timestamp in x_abstract[:]]
            plt.xticks(x_abstract[:], xtime, rotation=90, fontsize=8)  # 显示时，字体旋转90，字体大小为8
            plt.ylabel("Tweets numbers per 60S")
            plt.title("distribution of shooting")
            plt.grid(True)
            #plt.show()

        plt.savefig("../figure/line.jpg")
        plt.show()

    """
    将处理好的状态用柱状图的形式展示出来
    """
    def plt_bar_graph(self, path=r'../data_created/state_list.txt', max_repeat_num = 1):
        #max_repeat_num += 1

        plt.figure(figsize=(60, 24))
        # fig, ax = plt.subplots()
        ax = plt.gca()

        # data = [[0, 4, 92], [1.0, 33, 37], [1.0, 76, 92], [2.0, 76, 77]]
        data = []

        centers = []
        binned_data = []
        heights = []
        lefts = []

        file = codecs.open(path, mode='r', encoding="utf-8")
        # data_read = file.read()

        time_start_list = []
        time_end_list = []

        for line in file:
            text = line.strip()
            text = text.split(' ', 3)
            # print text[1]
            list_temp = []
            start_time = float(long((long(text[1])) / (1000)))
            end_time = float(long((long(text[2])) / (1000)))
            list_temp.append(int(float(text[0])))
            list_temp.append(start_time)
            list_temp.append(end_time)
            # print list_temp
            if list_temp[0] >= 0:
                data.append(list_temp)
            time_start_list.append(start_time)
            time_end_list.append(end_time)

        time_start = np.min(time_start_list)
        time_end = np.max(time_end_list)
        #print (time_end - time_start) / (3600 * 24)
        #print time_start
        #print time_end
        #print time_transform.timestamp_datetime(time_start)
        #print time_transform.timestamp_datetime(time_end)

        length = len(data)
        for item in data:
            centers.append(item[0])
            binned_data.append((item[2] - item[1]))
            heights.append(0.5)
            lefts.append(item[1])

        # 进行坐标转换
        x_abstract = range(int(time_end - time_start)) + time_start
        x_abstract = x_abstract[::36000]
        xtime = [datetime.datetime.fromtimestamp(float(timestamp)) for timestamp in x_abstract[:]]

        xfmt = md.DateFormatter('%Y.%m.%d %H:%M:%S')
        # ax.xaxis.set_major_formatter(xfmt)
        plt.xticks(x_abstract[:], xtime, rotation=90, fontsize=8)  # 显示时，字体旋转90，字体大小为8

        ax.barh(centers, binned_data, height=heights, left=lefts)

        plt.grid(True)
        plt.savefig("../figure/bar.jpg")
        plt.show()

    """
    将时间文件和文本文件里将需要的时间段的数据提取出来
    """
    def select_file(self, start_time, end_time, path_read = r'../data_created/data_time.txt', path_write = r'../data_created/data_time_selected.txt'):
        #得到所需要的时间的开始与结束的时间戳
        start_time = long(time_transform.datetime_timestamp(start_time))
        end_time = long(time_transform.datetime_timestamp(end_time))
        #因为得到的时间戳为以秒计时的，需要将其转换为以微妙计时
        start_time *= 1000
        end_time *= 1000

        file_read = codecs.open(path_read, mode='r', encoding="utf-8")
        file_write = codecs.open(path_write, mode='w', encoding="utf-8")

        flag_start = False
        count = 0

        for time in file_read:
            if long(time) >= long(start_time):
                if not flag_start:
                    start_count = count
                    flag_start = True
                if long(time) <= long(end_time):
                    end_count = count
                    file_write.write(str(time))
            count += 1

        file_read.close()
        file_write.close()

    """
    利用自动状态机的方法得到不同时间段的状态编号，并将时间段与状态索引储存在文本文件中
    """
    def cal_state_list(self, path_write = r'../data_created/state_list.txt'):
        self.state_list = kleinberg(self.time_processed, s=2, gamma=0.01)
        #print self.time_processed

        if self.max_repeat_num != 1:
            for state in self.state_list:
                state[1] = long(state[1] / 2)
                state[2] = long(state[2] / 2)

        file = codecs.open(path_write, mode='w', encoding="utf-8")
        for state in self.state_list:
            for item in state:
                file.write(str(item) + ' ')
            file.write('\n')
        file.close()

    """
    从状态列表中找到各个事件所对应的第一个1状态
    方法：若出现2及以上状态，认为该天出现了事件,再从其中找到所属的1状态
    """

    def find_event_time(self, path_read=r'../data_created/state_list.txt'):
        file_state = codecs.open(path_read, mode='r', encoding="utf-8")

        start_time_list = []
        end_time_list = []
        event_time_list = []
        data_list = []

        for line in file_state:
            text = line.strip()
            text = text.split(' ', 3)
            list_temp = []
            state = int(float(text[0]))
            start_time = long(long(text[1]) / 1000)
            end_time = long(long(text[2]) / 1000)
            start_time_list.append(start_time)
            end_time_list.append(end_time)
            temp_list = [state, start_time, end_time]
            data_list.append(temp_list)

        start_time_all = min(start_time_list)
        end_time_all = min(end_time_list)
        # event_time.append([start_time_all,end_time_all])

        # 先找到一个2状态，认为其前后一天从属于该2状态所属的时间
        for data in data_list:
            state = data[0]
            start_time = data[1]
            end_time = data[2]
            if state >= 2:
                # 假设改状态前后一天为事件持续时间
                start_time_event = start_time - 3600 * 6
                end_time_event = end_time + 3600 * 6

                # print "\t开始时间：\t" + time_transform.timestamp_datetime_GMT(start_time_event)
                # print "\t结束时间：\t" + time_transform.timestamp_datetime_GMT(end_time_event)
                # print event_time_list

                if not len(event_time_list):
                    # 列表仍为空，需要加入
                    event_time_list.append([start_time_event, end_time_event])
                else:
                    for event_time in event_time_list:
                        if start_time_event < event_time[0]:
                            if end_time_event >= event_time[0]:
                                # 认为其为同一事件，并将开始时间向前推
                                event_time[0] = start_time_event
                            else:
                                # 认为其是不同事件
                                event_time_list.append([start_time_event, end_time_event])
                        elif end_time_event >= event_time[1]:
                            if start_time_event <= event_time[1]:
                                event_time[1] = end_time_event
                            else:
                                event_time_list.append([start_time_event, end_time_event])
                # print "\t开始时间：\t" + time_transform.timestamp_datetime_GMT(event_time_list[0][0])
                # print "\t结束时间：\t" + time_transform.timestamp_datetime_GMT(event_time_list[0][1]) + "\n"

        # 按开始时间将事件的时间段进行排序
        # 排序方式：冒泡排序
        length = len(event_time_list)
        n = length
        for iter in range(length):
            i = 0
            while i < (iter - 1):
                i += 1
                if event_time_list[i][0] > event_time_list[i + 1][0]:
                    temp_time = event_time_list[i]
                    event_time_list[i] = event_time_list[i + 1]
                    event_time_list[i + 1] = temp_time

        # 将有重合时间的事件进行合并
        flag_has_overlap = True
        count = 0

        while flag_has_overlap:
            flag_has_overlap = False
            # print "has overlap"
            last_time = 0
            for count in range(len(event_time_list)):
                if count != 0:
                    if event_time_list[count][0] < event_time_list[count - 1][1]:
                        flag_has_overlap = True
                        break
            if flag_has_overlap:
                for iter in range(len(event_time_list)):
                    if iter == (count - 1):
                        event_time_list[iter][1] = event_time_list[iter + 1][1]
                    if iter > count:
                        event_time_list[iter - 1] = event_time_list[iter]
                event_time_list.pop()

        print "共有%d个事件" % len(event_time_list)
        count = 0

        # 找每个事件的时间期间其中的1状态
        for event_time in event_time_list:
            # 将开始值设为最大值，将终止值设为最小值
            start_time_event = event_time[1]
            end_time_event = event_time[0]

            for data in data_list:
                state = data[0]
                start_time = data[1]
                end_time = data[2]
                if state == 1:
                    if (start_time > event_time[0]) and (end_time < event_time[1]):
                        if start_time < start_time_event:
                            start_time_event = start_time
                        elif end_time > end_time_event:
                            end_time_event = end_time

            # event_time[0] = start_time_event
            # event_time[1] = end_time_event

            start_time = time_transform.timestamp_datetime_GMT(event_time_list[count][0])
            end_time = time_transform.timestamp_datetime_GMT(event_time_list[count][1])
            print "第%d个事件：" % (count + 1)
            print "\t由2状态找到的事件的大致时间："
            print "\t开始时间：\t" + start_time
            print "\t结束时间：\t" + end_time

            event_time[0] = start_time_event
            event_time[1] = end_time_event

            start_time = time_transform.timestamp_datetime_GMT(event_time_list[count][0])
            end_time = time_transform.timestamp_datetime_GMT(event_time_list[count][1])
            print "\t由1状态找到的事件的准确时间："
            print "\t开始时间：\t" + start_time
            # print "\t结束时间：\t" + end_time
            count += 1

        file_state.close()


if __name__ == "__main__":
    time_start = time.time()

    #选取所要检测的时间段
    month = 3
    start_date = 20
    end_date = 21
    start_time = '2018-' + str(month) + '-' + str(start_date) + ' 19:00:00'
    end_time = '2018-' + str(month) + '-' + str(end_date) + ' 21:00:00'

    dataprocess = Dataprocess(200, month, start_time, end_time)
    array = np.array(dataprocess.time_processed)
    #将所选取的时间段内的文本的数量画出
    dataprocess.plt_line_graph(dataprocess.time, 24*10)

    #计算状态序列
    dataprocess.cal_state_list()
    #将状态序列画出
    dataprocess.plt_bar_graph(path=r'../data_created/state_list.txt', max_repeat_num=dataprocess.max_repeat_num)

    #在得到的状态序列中找到发生的事件
    print "\n"
    dataprocess.find_event_time(path_read = r'../data_created/state_list.txt')

    time_end = time.time()
    print "总耗时:\t"+str(time_end - time_start)
