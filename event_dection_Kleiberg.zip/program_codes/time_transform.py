# -*- coding: utf-8 -*-

import time
import datetime
import matplotlib.dates as md

"""
将时间戳转换为北京时间
"""
def timestamp_datetime(value):
    format = '%Y-%m-%d %H:%M:%S'
    # value为传入的值为时间戳(整形)，如：1332888820
    value = time.localtime(value)
    ## 经过localtime转换后变成
    ## time.struct_time(tm_year=2012, tm_mon=3, tm_mday=28, tm_hour=6, tm_min=53, tm_sec=40, tm_wday=2, tm_yday=88, tm_isdst=0)
    # 最后再经过strftime函数转换为正常日期格式。
    dt = time.strftime(format, value)
    return dt

"""
将北京时间转换为时间戳
"""
def datetime_timestamp(dt):
    # dt为字符串
    # 中间过程，一般都需要将字符串转化为时间数组
    format = '%Y-%m-%d %H:%M:%S'
    time.strptime(dt, format)
    ## time.struct_time(tm_year=2012, tm_mon=3, tm_mday=28, tm_hour=6, tm_min=53, tm_sec=40, tm_wday=2, tm_yday=88, tm_isdst=-1)
    # 将"2012-03-28 06:53:40"转化为时间戳
    s = time.mktime(time.strptime(dt, '%Y-%m-%d %H:%M:%S'))
    return int(s)



def time_try(value):
    time_local = time.localtime(value)
    time_international = time.gmtime(value)
    print time_local
    print time_international

def datetime_try(value):
    xtime = datetime.datetime.fromtimestamp(value)
    print xtime
    xtime = md.date2num(xtime)
    print xtime

def timestamp_hour(timestamp):
    #如果时间戳是毫秒为单位的，则去掉最后三位
    if timestamp > 10000000000:
        timestamp = timestamp / 1000
    #print timestamp_datetime(timestamp)
    remainder = timestamp % 3600
    new_timestamp = timestamp - remainder
    #print timestamp_datetime(new_timestamp)
    return new_timestamp

"""
将时间输入，返回对应的时间戳
"""
def datetime_timestamp_GMT(strValue):
    d = datetime.datetime.strptime(strValue, "%Y-%m-%d %H:%M:%S.%f")
    t = d.timetuple()
    timeStamp = int(time.mktime(t))
    timeStamp = float(str(timeStamp) + str("%06d" % d.microsecond)) / 1000000
    return timeStamp

"""
将时间戳转换为标准时间并输出
输入的时间戳的小数部分可以输出为秒的小数部分
"""
def timestamp_datetime_GMT(timestamp):
    d = datetime.datetime.fromtimestamp(float(timestamp))
    format = "%Y-%m-%d %H:%M:%S.%f"
    str_time = d.strftime(format)
    return str_time


if __name__ == '__main__':
    #d = datetime_timestamp('2012-03-28 06:53:40')
    #d = datetime_timestamp_GMT('2018-3-18 12:00:00')
    #print d
    #s = timestamp_datetime(1518638766611/1000 - 3600*11)
    #print s
    #s = timestamp_datetime(1521549627377 / 1000 - 3600*8)
    #print s
    #time_try(1521043200)
    #datetime_try(1521043200)
    #timestamp_hour(1521044200123)
    d = timestamp_datetime_GMT(3043076066.0/2)
    print d
    d = datetime_timestamp_GMT('2066-06-07 02:54:26.000000')
    print d