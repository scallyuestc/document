# -*- coding:utf-8 -*-

import time
import matplotlib.pyplot as plt
#from pymongo import MongoClient
import pymongo
import numpy as np
import codecs
import codecs
import time

class Database(object):
    """
    进行数据库连接的相关的尝试
    """
    def __init__(self, host, db, collection):
        self.num = 0
        self.mongo_conn = self.connect_mongo(host, db, collection)
        self.text = []
        self.timestamp = []
        self.time_start = time.time()

    #显示数据集起始与终止时间
    def show_collection_time(self):
        cursor = self.mongo_conn.find().sort([("_id", 1)]).limit(1)
        start_timestamp = cursor[0].get("created_at_bj")
        print cursor[0].get('_id')
        start_time = self.timestamp_datetime(start_timestamp)
        print "开始时间：\t\t"+ str(start_time)
        cursor = self.mongo_conn.find().sort([("_id", -1)]).limit(1)
        end_timestamp = cursor[0].get("created_at_bj")
        end_time = self.timestamp_datetime(end_timestamp)
        print "结束时间：\t\t"+ str(end_time)
        size_collection = self.mongo_conn.count()
        print "数据集大小：\t" + str(size_collection)

    def connect_mongo(self, host, db, collection):
        client = pymongo.MongoClient("mongodb://" + host)
        db = client.get_database(db).get_collection(collection)
        return db

    def timestamp_datetime(self, value):
        format = '%Y-%m-%d %H:%M:%S'
        # value为传入的值为时间戳(整形)，如：1332888820
        value = time.localtime(value)
        ## 经过localtime转换后变成
        ## time.struct_time(tm_year=2012, tm_mon=3, tm_mday=28, tm_hour=6, tm_min=53, tm_sec=40, tm_wday=2, tm_yday=88, tm_isdst=0)
        # 最后再经过strftime函数转换为正常日期格式。
        dt = time.strftime(format, value)
        return dt

    def datetime_timestamp(self, dt):
        # dt为字符串
        # 中间过程，一般都需要将字符串转化为时间数组
        time.strptime(dt, '%Y-%m-%d %H:%M:%S')
        ## time.struct_time(tm_year=2012, tm_mon=3, tm_mday=28, tm_hour=6, tm_min=53, tm_sec=40, tm_wday=2, tm_yday=88, tm_isdst=-1)
        # 将"2012-03-28 06:53:40"转化为时间戳
        s = time.mktime(time.strptime(dt, '%Y-%m-%d %H:%M:%S'))
        return int(s)

    def connect(self):
        cursor = self.mongo_conn.find().sort([("_id", 1)]).skip(20000000).limit(2)
        tweets_cursor_size = cursor.count(True)
        #print tweets_cursor_size
        #for tweet in cursor:
            #print tweet.get("created_at_bj")

    def paint_graph_try(self):
        x = np.linspace(1, 5, num = 5)
        print x
        y = [1, 2, 3, 4, 5]
        #y = np.array(y)
        plt.plot(x, y, linestyle='-', color='green', marker='H')
        plt.show()

    def find_keywords(self,maxnum=10000, skipnum=0):
        cursor = self.mongo_conn.find().skip(maxnum-skipnum).limit(skipnum)
        count = 0
        for tweet in cursor:
            text = tweet.get("text")
            if "terrorism" in text:
                self.text.append(text)
                self.timestamp.append(tweet.get("created_at_bj"))
                count += 1
        print count
        #print self.text
        #print self.timestamp

    def write_file(self):
        file = codecs.open(r'data.txt', mode='w', encoding = "utf-8")
        for time in self.timestamp:
            file.write(str(time) + '\n')
        file.close()

    def read_file(self):
        file = codecs.open(r'data.txt', mode='r', encoding="utf-8")
        data_read = file.read()
        print data_read
        file.close()

    def getdata_1(self):
        iternum = 5
        step = 100000
        maxnum = 10000000
        for count in range(iternum):
            rate = float(count + 1) / float(iternum)
            print "rate:\t" + str(rate)
            self.find_keywords(maxnum, count*step)
            print "rate:\t" + str(rate) + "\tOK"
            time_process = time.time()-self.time_start
            print time_process
        #print self.timestamp
        self.write_file()

    def write_data(self, text):
        if "Terrorism" in text:
            print "OK"

    def getdata(self):
        file_text = codecs.open(r'data_text.txt', mode='w')
        file_time = codecs.open(r'data_time.txt', mode='w', encoding="utf-8")
        colle = self.mongo_conn
        cursor = colle.find().sort([("_id", 1)]).limit(1)
        first_tweet = cursor[0]
        timestamp = first_tweet.get("created_at_bj")
        #1521475200

        threshold = self.datetime_timestamp('2018-2-10 00:00:00')
        end_time = self.datetime_timestamp('2018-2-20 00:00:00')
        step = 10000

        if "created_at_bj_1" in colle.index_information().keys():
            cursor = colle.find_one({"created_at_bj": {"$gte": threshold}})
        else:
            cursor = colle.find_one({"created_at_bj": {"$lte": threshold}})
        new_id = cursor.get("_id")
        begin_time = cursor.get("created_at_bj")
        print "begin time:", time.strftime("%Y %m %d %H:%M:%S", time.localtime(begin_time))
        print "new_id event detect: ", new_id

        last_pos_id = new_id

        count = 0
        wordcount = 0
        flag = False

        while flag == False:
            tweets_cursor = colle.find({'_id': {'$gt': last_pos_id}}).sort([('_id', 1)]).limit(step)
            #print tweets_cursor.count()
            last_tweet = tweets_cursor[step-1]
            last_time = last_tweet.get('created_at_bj')
            print "last_time:\t" + str(self.timestamp_datetime(last_time))
            if last_time >= end_time:
                flag = True
            count += 1
            last_pos_id = last_tweet.get('_id')
            wordcount_iter = 0
            for tweet in tweets_cursor:
                text = tweet.get('text')
                time_tweet = tweet.get('timestamp_ms')
                if "Terrorism" in text or "terrorism" in text or "shooting" in text or "shoot" in text:
                    wordcount += 1
                    wordcount_iter += 1
                    text = text.replace("\n", "").replace("\t", "").replace("\r", "")
                    text = text.encode("unicode-escape").decode("string_escape")
                    file_text.write(str(text) + '\n')
                    file_time.write(str(time_tweet) + '\n')
            print wordcount_iter


        #print last_tweet.get('created_at_bj')
        print "iterNum: \t" + str(count)
        print "wordcount:\t" + str(wordcount)
        file_text.close()
        file_time.close()

if __name__ == "__main__":
    database = Database("kb314:fzdwxxcl.314@121.49.99.14:30011", "KeywordsTweets", "Terrorism4")
    database.getdata()
    #database.show_collection_time()
    #database.read_file()